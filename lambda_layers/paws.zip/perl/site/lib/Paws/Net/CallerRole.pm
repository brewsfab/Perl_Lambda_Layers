package Paws::Net::CallerRole;
  use Moose::Role;

  requires 'do_call';
1;
