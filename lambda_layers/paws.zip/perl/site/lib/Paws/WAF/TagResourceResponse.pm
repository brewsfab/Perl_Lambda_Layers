
package Paws::WAF::TagResourceResponse;
  use Moose;

  has _request_id => (is => 'ro', isa => 'Str');

### main pod documentation begin ###

=head1 NAME

Paws::WAF::TagResourceResponse

=head1 ATTRIBUTES


=head2 _request_id => Str


=cut

1;