package Spiffy::mixin;
1;
